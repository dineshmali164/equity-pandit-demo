<?php

const ROLE_ADMIN = 'admin';
const ROLE_SELLER = 'seller';
const ROLE_USER = 'user';
const PAYMENT_CASH_ON_DELIVERY = 'cod';
