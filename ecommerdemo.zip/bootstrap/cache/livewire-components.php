<?php return array (
  'admin.seller.index' => 'App\\Http\\Livewire\\Admin\\Seller\\Index',
  'admin.user.index' => 'App\\Http\\Livewire\\Admin\\User\\Index',
  'order.create' => 'App\\Http\\Livewire\\Order\\Create',
  'products.index' => 'App\\Http\\Livewire\\Products\\Index',
  'products.manage' => 'App\\Http\\Livewire\\Products\\Manage',
  'products.show' => 'App\\Http\\Livewire\\Products\\Show',
  'register' => 'App\\Http\\Livewire\\Register',
  'user.products.index' => 'App\\Http\\Livewire\\User\\Products\\Index',
);